#import <UIKit/UIKit.h>

//! Project version number for FaceTracker.
FOUNDATION_EXPORT double FaceTrackerVersionNumber;

//! Project version string for FaceTracker.
FOUNDATION_EXPORT const unsigned char FaceTrackerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <FaceTracker/PublicHeader.h>
#import <FaceTracker/FaceTrackerPipeline.h>


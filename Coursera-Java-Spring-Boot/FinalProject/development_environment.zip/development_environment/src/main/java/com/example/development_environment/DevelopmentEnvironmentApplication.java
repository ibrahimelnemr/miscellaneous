package com.example.development_environment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DevelopmentEnvironmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(DevelopmentEnvironmentApplication.class, args);
	}

}

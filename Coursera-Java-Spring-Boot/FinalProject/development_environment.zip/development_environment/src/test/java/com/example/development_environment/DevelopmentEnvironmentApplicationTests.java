package com.example.development_environment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DevelopmentEnvironmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
